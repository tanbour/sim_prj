var loginApp = angular.module("loginApp", ['ngRoute', 'Encrypt']);
//用户登录状态
loginApp.constant('AUTH_EVENTS', {
    loginSuccess: 'auth-login-success',
    loginFailed: 'auth-login-failed',
    logoutSuccess: 'auth-logout-success',
    sessionTimeout: 'auth-session-timeout',
    notAuthenticated: 'auth-not-authenticated',
    notAuthorized: 'auth-not-authorized'
});
//用户权限
loginApp.constant('USER_ROLES', {
    all: '*',
    admin: 'admin',
    editor: 'editor',
    guest: 'guest'
});

loginApp.controller('loginController', ['$rootScope', '$scope', '$http', 'AUTH_EVENTS', 'AuthService', 'Md5', '$location', 'CONST_ERRORCODE', function($rootScope, $scope, $http, AUTH_EVENTS, AuthService, Md5, $location, CONST_ERRORCODE) {
    $scope.submitForm = function() {
        var domResult = angular.element(document.getElementById("result"))[0]
        var auth_event = AUTH_EVENTS;
        var user = angular.copy($scope.user);
        user.password = Md5.hex_md5(user.userName + Md5.hex_md5(Md5.hex_md5(user.password)));
        AuthService.login(user).then(function(u) {
            $rootScope.$broadcast(AUTH_EVENTS.loginSuccess);
            $scope.$parent.setCurrentUser(u);
            domResult.innerHTML="";
            window.location.href = "config.html";
        }).catch(function(error) {
            domResult.innerHTML=CONST_ERRORCODE[error.errorcode];
            $rootScope.$broadcast(AUTH_EVENTS.loginFailed);
        });
    }
}]);