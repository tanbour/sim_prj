var configApp = angular.module("configApp", ['ngRoute', 'ngMessages', 'ui.bootstrap']);

configApp.constant("CONST_ERRORCODE", {
    "-1": "系统错误",
    "1001": "规格包不存在"
});
configApp.directive('errorMessage', ['$compile', '$sce', function($compile, $sce) {
    return {
        restrict: 'A',
        scope: {
            title: '@'
        },
        require: 'ngModel',
        link: function(scope, element, attr, ngModel) {
            var subScope = scope.$new(true);
            var parenNode = element.parent();
            parenNode.addClass("has-feedback");
            subScope.hasError = function() {
                var re = (ngModel.$$parentForm.$submitted || ngModel.$dirty) && ngModel.$invalid;
                if (re) {
                    parenNode.addClass("has-error");
                } else {
                    parenNode.removeClass("has-error");
                }
                // if (ngModel.$dirty && !ngModel.$invalid) {
                //     parenNode.addClass("has-success");
                // } else {
                //     parenNode.removeClass("has-success");
                // }
                return re;
            }
            subScope.htmlTooltip = $sce.trustAsHtml(scope.title);
            var html_str = '<span ng-if="hasError()" class="glyphicon glyphicon-warning-sign form-control-feedback" uib-tooltip-html="htmlTooltip"  tooltip-trigger="none" tooltip-is-open="true" tooltip-placement="bottom"></span>';
            var errorElement = $compile(html_str)(subScope);
            element.after(errorElement);
        }
    };
}]);

configApp.factory('paramService', function($http, $q) {
    var paramService = {};
    paramService.get = function() {
        var def = $q.defer();
        $http({
            method: 'get',
            url: '/config'
        }).then(function(response) {
            var data = response.data;
            if (data.errorcode == 0) {
                def.resolve(data.message);
            } else {
                def.reject(data);
            }
        }, function(err) {
            def.reject(err);
        });
        return def.promise;
    };
    paramService.save = function(param) {
        var def = $q.defer();
        $http({
            method: 'post',
            url: '/config',
            data: param
        }).then(function(response) {
            var data = response.data;
            if (data.errorcode == 0) {
                def.resolve(data.message);
            } else {
                def.reject(data);
            }
        }, function(err) {
            def.reject(err);
        });
        return def.promise;
    };
    paramService.apply = function(command) {
        var def = $q.defer();
        $http({
            method: 'post',
            url: '/apply',
            data: command
        }).then(function(response) {
            var data = response.data;
            if (data.errorcode == 0) {
                def.resolve(data.message);
            } else {
                def.reject(data);
            }
        }, function(err) {
            def.reject(err);
        });
        return def.promise;
    };
    return paramService;
});

configApp.factory('resultService', function($http, $q) {
    var resultService = {};
    resultService.setResult = function(id, isSuccess, info, alert) {
        var color;
        if (alert === "alert") {
            color = "black";
        } else {
            color = isSuccess ? "green" : "red";
        }
        var domain = typeof id === 'object' ? id : angular.element(document.getElementById(id))[0];
        if (domain) {
            if (isSuccess) {
                domain.innerHTML = info ? info : "成功";
            } else {
                domain.innerHTML = info ? info : "失败";
            }
            domain.style.color = color;
            domain.style.backgroundColor = "#FFFF00";
            domain.style.opacity = 1;
            if (isSuccess) {
                setTimeout(function() {
                    domain.innerHTML = "";
                }, 2000);
            }
        }
    };
    return resultService;
});
configApp.controller('configController', ['$rootScope', '$scope', '$sce', 'paramService', 'resultService', 'CONST_ERRORCODE', function($rootScope, $scope, $sce, paramService, resultService, CONST_ERRORCODE) {
    //console.log(CONST_ERRORCODE);
    var currentUser = {
        id: sessionStorage.getItem("id"),
        name: sessionStorage.getItem("name"),
        role: sessionStorage.getItem("role")
    };
    if (currentUser.id) {
        $scope.currentUser = currentUser;
    } else {
        window.location.href = "index.html#!/login";
    }
    //表单校验
    $scope.regex_ip = /^((2(5[0-5]{1}|[0-4]\d{1})|[0-1]?\d{1,2})(\.(2(5[0-5]{1}|[0-4]\d{1})|[0-1]?\d{1,2})){3})$/;
    $scope.regex_ip_port = /^((?:(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(?:25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?[1-9])))(\:\d{1,5})*)$/;
    $scope.regex_port = /^(\d|[1-9]\d{1,3}|[1-5]\d{4}|[6][0-5][0-5][0-3][0-5])$/;
    $scope.regex_port_from_to = /^(\d|[1-9]\d{1,3}|[1-5]\d{4}|[6][0-5][0-5][0-3][0-5])-(\d|[1-9]\d{1,3}|[1-5]\d{4}|[6][0-5][0-5][0-3][0-5])$/;


    paramService.get().then(function(param) {
        var profile_parm = param.profile_parm;
        var apply_param = param.apply_param;
        var data_server_hosts = profile_parm.data_server_hosts;
        for (var key in data_server_hosts) {
            profile_parm.data_server_hosts = key;
            break;
        }
        $scope.data = profile_parm;
        $scope.command = apply_param;
    }).catch(function(error) {
        alert(error.errorcode);
    });

    $scope.fileChanged = function(ele) {
        $scope.files = ele.files;
        $scope.$apply(); //传播Model的变化。
    }

    $scope.logout = function($event) {
        $scope.currentUser = null;
        window.location.href = "index.html#!/login";
        $event.preventDefault();
    };

    $scope.save = function() {
        if (!$scope.configForm.$invalid) {
            var param = {};
            var param = angular.copy($scope.data);
            var data_server_hosts = param.data_server_hosts;
            param.data_server_hosts = {};
            param.data_server_hosts[data_server_hosts] = data_server_hosts;
            paramService.save(param).then(function(message) {
                resultService.setResult("result", true, "参数保存成功");
            }).catch(function(error) {
                resultService.setResult("result", false, "参数保存失败: " + CONST_ERRORCODE[error.errorcode]);
            });
        } else {
            $scope.configForm.$setSubmitted(true);
            resultService.setResult("result", false, "表单校验失败");
        }
    };

    $scope.apply = function() {
        //if (!$scope.configForm.package_path.$invalid && !$scope.configForm.kubernetes_docker_registry.$invalid) {
        if (!$scope.configForm.$invalid) {
            var param = {
                "apply_param": $scope.command
            };
            var profile_parm = angular.copy($scope.data);
            var data_server_hosts = profile_parm.data_server_hosts;
            profile_parm.data_server_hosts = {};
            profile_parm.data_server_hosts[data_server_hosts] = data_server_hosts;
            param["profile_parm"] = profile_parm;
            paramService.apply(param).then(function(message) {
                resultService.setResult("result", true, "参数应用成功");
            }).catch(function(error) {
                resultService.setResult("result", false, "参数应用失败: " + CONST_ERRORCODE[error.errorcode]);
            });
        } else {
            $scope.configForm.$setSubmitted(true);
            resultService.setResult("result", false, "应用参数校验失败");
        }
    };
}]);