#!/usr/bin/env python
# -*- coding: UTF-8 -*-

SUCCESS = 0
ERRORCODE_SYSTEM = -1                       #系统错误
ERRORCODE_FILE_NOT_EXIST = 1001             #文件不存在
ERRORCODE_USER_OR_PASSWORD_FAULT = 1002     #用户名或密码错误
