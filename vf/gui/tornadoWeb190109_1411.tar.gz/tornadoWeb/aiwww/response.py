#!/usr/bin/env python
# -*- coding: UTF-8 -*-

class Response():

    def __init__(self, errorcode, message):
        self.errorcode = errorcode
        self.message = message